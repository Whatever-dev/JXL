package com.javaexcel.automation.core.enums;

public enum ParameterDataType {
	
	String,
	Integer,
	String_Number,
	Number,
	StringEnum,
	IntegerEnum,
	Unknown

}
