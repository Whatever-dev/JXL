package com.javaexcel.automation.core.enums;

public enum TestFilterType {
	Name,
	TestID,
	ConfigurationID,
	TestCaseID

}
