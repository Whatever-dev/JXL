package com.javaexcel.automation.core.reporting;

import java.util.Comparator;

import com.javaexcel.automation.core.data.ITestInstance;

public class TestReportComparator  implements Comparator<ITestInstance>{
	
	@Override
	public int compare(ITestInstance ts1,ITestInstance ts2)
	{
		int id1=Integer.parseInt(ts1.getID());
		int id2=Integer.parseInt(ts2.getID());
		
		return id1-id2;
		
	}

}
