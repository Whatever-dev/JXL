package com.javaexcel.automation.core.reporting;

import java.io.File;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.javaexcel.automation.core.data.Config;
import com.javaexcel.automation.core.data.Configurables;
import com.javaexcel.automation.core.data.ITestResult;
import com.javaexcel.automation.core.listeners.CustomLogger;

public class HTMLReporter extends AbstractReporter {
		private static final String FRAMES_PROPERTY="org.uncommons.reportng.frames";
		private static final String ONLY_FAILURES_PROPERTY="org.uncommons.reportng.failures-only";
		
		private static final String TEMPLATES_PATH="templates/html";
		private static final String INDEX_FILE="index.html";
		private static final String SUITES_FILE="suites.html";
		private static final String  OVERVIEW_FILE="overview.html";
		private static final String GROUPS_FILE="groups.html";
		private static final String RESULTS_FILE="results.html";
		private static final String OUTPUT_FILE="output.html";
		private static final String CUSTOM_STYLE_FILE="custom.css";
		private static final String CLASS_RESULTS_TEMPLATE_PATH=TEMPLATE_PATH+"class-results.html.vm";
		private static final String CLASS_RESULTS_TEMPLATE_KEY="classResultsTemplatePath";
		private static final String SUITE_KEY="suite";
		private static final String SUITES_KEY="suites";
		private static final String GROUPS_KEY="groups";
		private static final String RESULT_KEY="result";
		private static final String FAILED_CONFIG_KEY="failedConfigurations";
		private static final String SKIPPED_CONFIG_KEY="skippedConfigurations";
		private static final String PASSED_TESTS_KEY="passedTests";
		private static final String REQ_ID="reqId";
		private static final String ALL_TESTS_KEY="allTests";
		private static final String ONLY_FAILURES_KEY="onlyReportFailures";
		private static final String REPORT_DIRECTORY=Configurables.uploadDirectory;
		
		
		private static final Comparator<ITestNGMethod> METHOD_COMPARATOR=new TestMehodComparator();
		private static final Comparator<ITestResult> RESULT_COMPARATOR=new TestResultComparator();
		private static final Comparator<IClass> CLASS_COMPARATOR=new TestClassComparator();
		public String fileName;
		
		
		public HTMLReporter()
		{
			super(TEMPLATES_PATH);
		}
		
		//generate a set of html files that contain data about the outcome of the test suite
		@Override
		public void generateReport(List<XmlSuite> xmlSuites,
				List<ISuite>suites,
				String outputDirectoryName)
		{
			outputDirectoryName=REPORT_DIRECTORY;
			System.out.println("Report Path:" +outputDirectoryName);
			removeEmptyDirectories(new File(outputDirectoryName));
			System.setProperty("org.uncommons.reporting.escape-output", "false");
			
			boolean useFrames=Config.getProp(FRAMES_PROPERTY,"true").equals("true");
			boolean onlyFailures=Config.getProp(ONLY_FAILURES_PROPERTY,"false").equals("true");
			
			String id=Configurables.runID ==null ? TestManager.defaultRunId : Configurables.runID;
			File outputDirectory=new File(outputDirectoryName);
			outputDirectory.mkdirs();
			try {
				if(userFrames) {
					createFrameset(outputDirectory);
				}
				createOverview(suites,outputDirectory,!useFrames,onlyFailures);
				createSuiteList(suites,outputDirectory,onlyFailures);
				createGroups(suites,outputDirectory);
				createResults(suites,outputDirectory,onlyFailures);
				createLog(outputDirectory,onlyFailures);
				copyResources(outputDirectory);
				copyIconFiles("src/test/resources/reporting/home_button.ico",outputDirectory+"/home_button.ico");
				copyIconFiles("src/test/resources/reporting/back_button.ico",outputDirectory+"/back_button.ico");
				copyIconFiles("src/test/resources/reporting/forward_button.ico",outputDirectory+"/forward_button.ico");
				copyIconFiles("src/test/resources/reporting/jenkins.ico",outputDirectory+"/jenkins_button.ico");
				copyIconFiles("src/test/resources/reporting/pdf.ico",outputDirectory+"/pdf_button.ico");
				copyIconFiles("src/test/resources/reporting/log.ico",outputDirectory+"/log_button.ico");
				copyIconFiles("src/test/resources/reporting/alm.ico",outputDirectory+"/alm_button.ico");
				
			}
			catch(Exception ex) {
				ex.printStackTrace();
				throw new ReportNGException("Failed to generate HTML Report.",ex);
			}
			
			
		}
		
		private void createFrameset(File outputDirectory) throws Exception
		{
			VelocityContext context=createContext();
			generateFile(new File(outputDirectory,INDEX_FILE),INDEX_FILE+TEMPLATE_EXTENSION,context);
		}
		
		private void createOverview(List<ISuite> suites,File outputDirectory,boolean isIndex,boolean onlyFailures) throws Exception
		{
			VelocityContext context=createContext();
			context.put(SUITES_KEY,suites);
			context.put(ONLY_FAILURES_KEY,onlyFailures);
			context.put("HTTP_STATUS_PASS",CustomLogger.httpStatusPass);
			context.put("HTTP_STATUS_FAIL",CustomLogger.httpStatusFail);
			Set<String> httpStatusKeys=new HasSet<>();
			httpStatusKeys.addAll(CustomLogger.httpStatusPass.keySet());
			httpStatusKeys.addAll(CustomLogger.httpStatusFail.keySet());
			context.put("HTTP_STATUS_KEYS",httpStatusKeys);
			context.put("numberTool",new NumberTool());
			context.put("math",new MathTool());
			
			generateFile(new File(outputDirectory,isIndex ? INDEX_FILE : OVERVIEW_FILE),OVERVIEW_FILE + TEMPLATE_EXTENSION,context);
		}
		
		private void createSuiteList(List<ISuite> suites, File outputDirectory,boolean onlyFailures) throws Exception
		{
			VelocityContext context=createContext();
			context.put(SUITES_KEY,suites);
			context.put(ONLY_FAILURES_KEY,onlyFailures);
			generateFile(new File(outputDirectory,SUITES_FILE),SUITES_FILE + TEMPLATE_EXTENSION,context);
		}
}
