package com.javaexcel.automation.core.swagger;

public class ErrorInfo {
	
	private String errorCode;
	private String statusLine;
	private String errorDescription;
	
	private String fieldNameValidation="error[%d]field_name#%s";
	private String fieldValueValidation="error[%d]field_value#%s";
	private String fieldValueValidationForEmpty="error[%d]field_value#Exist";
	private String apiSpecificationUrl="error[%d]api_specification_url#%s";
	
	public ErrorInfo(String statusLine,String errorCode,String errorDescription)
	{
		this.statusLine=statusLine;
		this.errorCode=errorCode;
		this.errorDescription=errorDescription;
	}
	
	public String getFieldNameValidation()
	{
		return fieldNameValidation;
	}
	public String getFieldValueValidation()
	{
		return fieldValueValidation;
	}
	public String getFieldValueValidationForEmpty()
	{
		return fieldValueValidationForEmpty;
	}
	public String getAPISpecificationUrl() {
		return apiSpecificationUrl;
	}
	public String getErrorCode()
	{
		return errorCode;
	}
	public String getStatusLine()
	{
		return statusLine;
	}
	public String getErrorDescription()
	{
		return errorDescription;
	}
	
}
