package com.javaexcel.automation.core.swagger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.TreeMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.javaexcel.automation.core.data.Config;
import com.javaexcel.automation.core.data.Configurables;
import com.javaexcel.automation.core.enums.ParameterDataType;
import com.javaexcel.automation.core.enums.ParameterType;
import com.javaexcel.automation.core.table.Record;
import com.javaexcel.automation.core.table.Table;

public class SwaggerData {

	static TreeMap data=new TreeMap<String,TreeMap<String,ArrayList<ParameterInfo>>>(String.CASE_INSENSITIVE_ORDER);
	private static HashMap<String,Record> autoTestcaseMap=new HashMap<String,Record>();
	
	private static HashMap<String, ErrorInfo> errorData=new HashMap<String, ErrorInfo>();
	static int autoTestCaseIdCounter=10000;
	private static boolean swaggerRead= false;
	
	private void addPath(String path) {
		
		if(!data.containsKey(path))
		{
			TreeMap<String,ArrayList<ParameterInfo>> dataMap=new TreeMap<String,ArrayList<ParameterInfo>>();
			data.put(path, dataMap);
		}
	}
	
	private ParameterInfo getParameterInfo(String path,String parameterName,ParameterType parameterType)
	{
		addPath(path);
		TreeMap<String,ArrayList<ParameterInfo>> dataMap= (TreeMap<String,ArrayList<ParameterInfo>>)data.get(path);
		
		ParameterInfo parameterInfo=null;
		
		if(dataMap.containsKey(parameterName))
		{
			for (ParameterInfo paramInfo:dataMap.get(parameterName))
			{
				if(paramInfo.getParameterType()==parameterType)
					parameterInfo=paramInfo;
			}
			if(parameterInfo==null)
			{
				parameterInfo=new ParameterInfo();
				parameterInfo.setParameterName(parameterName);
				parameterInfo.setParameterType(parameterType);
				((ArrayList)dataMap.get(parameterName)).add(parameterInfo);
			}
			
		}else
		{
			ArrayList<ParameterInfo> pInfoList=new ArrayList<ParameterInfo>();
			dataMap.put(parameterName, pInfoList);
			parameterInfo=new ParameterInfo();
			parameterInfo.setParameterName(parameterName);
			parameterInfo.setParameterType(parameterType);
			pInfoList.add(parameterInfo);
		}
		return parameterInfo;
		
	}

	
	//processRef
	private void processRef(String refPath,JSONObject jsonRoot,String path,String paramName,ParameterType parameterType)
	{
		refPath = refPath.replace("#","");
		String[] arrRef=refPath.split("/");
		if(arrRef.length==3 && jsonRoot.get(arrRef[1]) !=null)
		{
			JSONObject jsonReferal=(JSONObject) jsonRoot.get(arrRef[1]);
			jsonReferal=(JSONObject) jsonReferal.get(arrRef[2]);
			
			if(jsonReferal.get("name")!=null)
				paramName=jsonReferal.get("name").toString().trim();
			if(paramName.equals("content-type")) retrun;
			if(jsonReferal.get("required") !=null && jsonReferal.get("type").toString().equals("object"))
			{
				this.setRequired((JSONArray)jsonReferal.get("required"),path,paramName,parameterType);
			}
			if(jsonReferal.get("properties") !=null)
			{
				this.setProperties(jsonRoot,(JSONObject)jsonReferal.get("properties"),path,paramName,parameterType);
			}
			if(jsonReferal.get("in")!=null)
			{
				if(jsonReferal.get("in").toString().trim().matches("header"))
				{
					parameterType=ParameterType.RequestHeaderAttribute;
				}
			}
			
			if(excludedValidationsMap.containsKey(paramName) && excludedValidationsMap.get(paramName).equalsIgnoreCase("true")) {
				
			}else
			{
				processProperties(jsonRoot,jsonReferal,paramName,path,parameterType);
			}
		}
	}
	
	private void processProperties(JSONObject jsonRoot,JSONObject jsonProperties,String paramName,String path,ParameterType parameterType)
	{
		
		if(paramName.equalsIgnoreCase("content-type")) return;
		
		ParameterInfo paramInfo = this.getParameterInfo(path, paramName, parameterType);
		JSONObject jsonParamDetails=jsonProperties;
		
		for(Map.Entry<Object,Object> parameterData: ((Map<Object,Object>)jsonParamDetails).entrySet())
		{
			String key=parameterData.getKey().toString();
			String value=parameterData.getValue().toString().trim();
			if(key.matches("type"))
			{
				boolean isEnum=false;
				if(jsonParamDetails.get("enum") != null)
					isEnum=true;
				
				if(datatypeOverrideMap.containsKey(paramInfo.getParameterName()))
				{
					String dtType=datatypeOverrideMap.get(paramInfo.getParameterName());
					if(dtType !=null && dtType.toLowerCase().equals("string_number"))
					{
						paramInfo.setParameterDataType(ParameterDataType.String_Number);
					}
					else if(dtType !=null && dtType.equalsIgnoreCase("integer"))
					{
						paramInfo.setParameterDataType(ParameterDataType.Integer);
					}
					
				}
				else if(value.matches("string"))
				{
					if(isEnum==true)
						paramInfo.setParameterDataType(ParameterDataType.StringEnum);
					else 
						paramInfo.setParameterDataType(ParameterDataType.String);
				}
				else if(value.matches("integer"))
				{
					if(isEnum==true)
						paramInfo.setParameterDataType((ParameterDataType.IntegerEnum);
					else
						paramInfo.setParameterDataType(ParameterDataType.Integer);
					
				}
				else if(value.matches("number"))
				{
					paramInfo.setParameterDataType(ParameterDataType.Number);
				}
			}
			else if(key.equalsIgnoreCase("$ref"))
			{
				processRef(value,jsonRoot,path,paramName,parameterType);
			}
			else if(key.equalsIgnoreCase("minlength"))
			{
				paramInfo.setMinLenght(Integer.valueOf(value));
			}
			else if(key.equalsIgnoreCase("maxlength"))
			{
				paramInfo.setMaxLenght(Integer.valueOf(value));
			}
			else if(key.equalsIgnoreCase("required"))
			{
				if(requiredOverrideMap.containsKey(paramInfo.getParameterName()))
				{
					String val=requiredOverrideMap.get(paramInfo.getParameterName());
					if(val.matches("true") || val.matches("false"))
						value=val;
				}
				paramInfo.setIsRequired((Boolean.valueOf(value));
			}
		}
	}
	
	private HashMap<String,String> getOverrideConfigData(String overrideString)
	{
		HashMap<String,String> overrideMap=new HashMap<String,String>();
		
		if(overrideString !=null)
		{
		  if(!overrideString.equals(""))
		  {
			  String[] arrReq=overrideString.split("!");
			  for(String col: arrReq)
			  {
				  if(col.split("#").length==2)
					  overrideMap.put(col.split("#")[0],col.split("#")[1].toLowerCase());
			  }
		  }
		}
		return overrideMap;
	}
	
	private void setRequired(JSONArray requiredParameters,String path,String paramName,ParameterType parameterType)
	{
		for(int j=0;j<requiredParameters.size();j++)
		{
			String requiredParam=requiredParameters.get(j).toString();
			if(paramName !="")
				requiredParam=paramName +"$"+requiredParam;
			if(requiredOverrideMap.containsKey(requiredParam))
			{
				String val=requiredOverrideMap.get(requiredParam);
				if(val.matches("true") || val.matches("false"))
				{
					ParameterInfo.paramInfo=this.getParameterInfo(path, requiredParam, parameterType);
					paramInfo.setIsRequired(Boolean.valueOf(val));
				}
			}
			else
			{
				ParameterInfo paramInfo=this.getParameterInfo(path, requiredParam, parameterType);
				paramInfo.setIsRequired(true);
			}
		}
	}
	
	private void setProperties(JSONObject jsonRoot,JSONObject jsonProperties,String path,String paramName,ParameterType parameterType)
	{
		for(Map.Entry<Object, Object> paramEntry: ((Map<Object,Object>)jsonProperties).entrySet())
		{
			String parameterName=((String)paramEntry.getKey()).trim();
			if(paramName !="")
				parameterName=paramName +"$" +parameterName;
			processProperties(jsonRoot,(JSONObject)paramEntry.getValue(),parameterName,path,parameterType);
		}
	}
	
	private JSONObject readFileAndGetJSONObject(String file)
	{
		BufferedReader br=null;
		StringBuilder jsonString =new StringBuilder();
		JSONObject jsonObj=null;
		try
		{
			if(file.contains(".yaml")) {
				return Utils.convertYamlToJson("src/test/resources" +file);
			}
			else {
				br=new BufferedReader(new FileReader(new File("src/test/resources/" +file)));
				{
					String line="";
					while((line = br.readLine()) !=null)
					{
						jsonString.append(line);
					}
				}
				jsonObj=(JSONObject)new JSONParser().parse(jsonString.toString());
			}
			}
		catch(Exception e)
		{
			System.err.println(this.resourceNameConfig +" - File read error - missing or invalid: " + exp.getMessage()+ "\nSkipping auto test case generation for " + this.resourceNameConfig);
			
		}
		finally
		{
			try {
				if(br !=null)
					br.close();
			}
			catch(Exception ex) {}
		}
		return jsonObj;
		}
	
	private static TreeMap<String,TreeMap<String,ArrayList<String>>> templateFiledCollection=new TreeMap<String,TreeMap<String,ArrayList<String>>>(String.CASE_INSENSITIVE_ORDER);
	
	private void readTemplate(String templateName)
	{
		if(templateFieldCollection.containsKey(templateName)==false)
		{
			JSONObject jsonRoot=readFileAndGetJSONObject("json-templates/"+templateName);
			if(jsonRoot !=null)
				getTemplateFields(jsonRoot,templateName,"");
		}
	}
	
	private void getTemplateFields(JSONObject jsonObj,String templateName,String fieldPath)
	{
		for(Map.Entry<Object,Object> pathEntry :((Map<Object,Object>)jsonObj).entrySet())
		{
			String fieldPath1="";
			if(fieldPath !="")
				fieldPath1=fieldPath + "$" + (String) pathEntry.getKey();
			else
				fieldPath1=(String)pathEntry.getKey();
			if(pathEntry.getValue() instanceof JSONObject)
			{
				getTemplateFields((JSONObject) pathEntry.getValue(),templateName,fieldPath1);
			}
			else
			{
				TreeMap<String,ArrayList<String>> templateFields=templateFieldCollection.get(templateName);
				if(templateFields == null)
				{
					templateFields=new TreeMap<String,ArrayList<String>>(String.CASE_INSENSITIVE_ORDER);
					templateFieldCollection.put(templateName,templateFields);
				}
				templateFields.put(fieldPath1, new ArrayList<String>());
			}
		}
	}
	
	private HashMap<String,String> requiredOverrideMap=new HashMap<String,String>();
	private HashMap<String,String> datatypeOverrideMap=new HashMap<String,String>();
	private HashMap<String,String> excludedValidationsMap=new HashMap<String,String>();
	private HashMap<String,String> pathHTTPMethodMap=new HashMap<String,String>();
	
	public void readSwagger()
	{
		requiredOverrideMap=getOverrideConfigData(this.requiredOverrideConfig);
		datatypeOverrideMap=getOverrideConfigData(this.dataTypeOverrideConfig);
		excludedValidationsMap=getOverrideConfigData(this.excludedValidations);
		
		if(swaggerRead==true) return;
		try {
			String swaggerFile=this.swaggerFile;
			JSONObject jsonRoot=readFileAndGetJSONObject("swagger/" + swaggerFile);
			JSONObject pathsJSON=null;
			if(jsonRoot !=null) {
				pathsJSON=((JSONObject) jsonRoot.get("paths"));
				
				for(Map.Entry<Object, Object> pathEntry : ((Map<Object,Object>)pathsJSON).entrySet())
				{
					String path=(String) pathEntry.getKey();
					this.addPath(path);
					Map<Object,Object>pathDetails=(Map<Object,Object>)pathEntry.getValue();
					for(Map.Entry<Object, Object> pathDetailEntry: pathDetails.entrySet())
					{
						if(pathHTTPMethodMap.containsKey(path)==false)
							pathHTTPMethodMap.put(path, (String)pathDetailEntry.getKey());
						Map<Object,Object> pathMethodDetails=(Map<Object,Object>)pathDetailEntry.getValue();
						
						if(pathMethodDetails.get("response")!=null)
						{
							if(((JSONObject)pathMethodDetails.get("responses")).get("400")!=null)
							{
								if((((JSONObject)((JSONObject)pathMethodDetails.get("responses")).get("400")).get("headers")!=null))
								{
									JSONObject headersJSON=(JSONObject)((JSONObject)((JSONObject)pathMethodDetails.get("responses")).get("400")).get("headers");
									for(Map.Entry<Object, Object>headerData : ((Map<Object,Object>)headersJSON).entrySet())
									{
										String headerName=headerData.getKey().toString();
										if(headerData.getValue() !=null && headerData.getValue() instanceof JSONObject)
										{
											if(((JSONObject) headerData.getValue()).get("type")!=null)
											{
												String headerDataType=((JSONObject)headerData.getValue()).get("type").toString();
												ParameterInfo headerParameter=this.getParameterInfo(path,headerName,ParameterType.ResponseHeaderAttribute);
												if(headerDataType.equalsIgnoreCase("string"))
													headerParameter.setParameterDataType(ParameterDataType.String);
													int[] statusCodes= {400};
													headerParameter.setStatusCodes(statusCodes);
											}
										}
									}
								}
							}
						}
						
						JSONArray parameterDetails=(JSONArray)pathMethodDetails.get("parameters");
						Object obj=new Object();
						ParameterType parameterType=ParameterType.RequestHeaderAttribute;
						for(int i=0;i<parameterDetails.size();i++)
						{
							obj=parameterDetails.get(i);
							if(obj!=null)
							{
								Object objParameterType=((JSONObject)obj).get("in");
								if(objParameterType!=null)
								{
									if(objParameterType.toString().trim().equalsIgnoreCase("body"))
									{
										parameterType=ParameterType.RequestBodyAttribute;
									}
									else if(objParameterType.toString().trim().equalsIgnoreCase("query") ||
											objParameterType.toString().trim().equalsIgnoreCase("path"))
									{
										parameterType=ParameterType.RequestQueryAttribute;
										if(obj instanceof JSONObject)
										{
											ParameterInfo paramInfo=null;
										   for(Map.Entry<Object, Object> getParametersData: ((Map<Object,Object>)(JSONObject)obj).entrySet())
										   {
											   String queryKey=getParametersData.getKey().toString();
											   String queryVal="";
											   if(getParametersData.getValue()!=null)
												   queryVal=getParametersData.getValue().toString();
											   if(queryKey.equalsIgnoreCase("name"))
											   {
												   paramInfo=this.getParameterInfo(path,queryVal,parameterType);
												   this.processProperties(jsonRoot,(JSONObject)obj,queryVal,path,parameterType);
											   }
										   }
												
										}
									} else if(objParameterType.toString().trim().equalsIgnoreCase("header"))
									{
										if(obj instanceof JSONObject)
										{
											ParameterInfo paramInfo=null;
											for(Map.Entry<Object,Object> getParametersData : ((Map<Object,Object>)(JSONObject) obj).entrySet())
											{
												String queryKey=getParametersData.getKey().toString();
												String queryVal="";
												if(getParametersData.getValue()!=null)
													queryVal=getParametersData.getValue().toString();
												if(excludedValidationsMap.containsKey(queryVal)
														&& excludedValidationsMap.get(queryVal).equalsIgnoreCase("true")) {
													continue;
												}	
												if(queryKey.equalsIgnoreCase("name"))
												{
													paramInfo=this.getParameterInfo(path, queryVal, parameterType);
													this.processProperties(jsonRoot, (JSONObject)obj, queryVal, path, parameterType);
												}
											}
										}
									}
								}
								
								if(((JSONObject)obj).get("$ref")!=null)
								{
									String ref=((JSONObject)obj).get("$ref").toString();
									processRef(ref,jsonRoot,path,"",parameterType);
								}
								Object objSchema =((JSONObject)obj).get("schema");
								if(objSchema !=null)
								{
									Object objRequired=((JSONObject)objSchema).get("required");
									if(objRequired!=null)
										setRequired((JSONArray)objRequired,path,"",parameterType);
									Object objProperties=((JSONObject)objSchema).get("properties");
									if(objProperties !=null)
									{
										JSONObject jsonProperties=(JSONObject)objProperties;
										setProperties(jsonRoot,jsonProperties,path,"",parameterType);
									}
								}
							}
						}
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
		finally
		{
			if(Config.getProp("multipleSwaggerSupport").equalsIgnoreCase("yes")) {
				swaggerRead=false;
			}
			else {
				swaggerRead=true;
			}
			buildErrorData();
		}
	}
	
	private void buildErrorData()
	{
		errorData.put(Constants.PARAMETER_HEADER_REQUIRED, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-007",
				"errors[%d]description#'%s' is missing from the request header."));
		errorData.put(Constants.PARAMETER_STRING_REQUIRED, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-008",
				"errors[%d]description#'%s' is missing from the request body of the request."));
		errorData.put(Constants.PARAMETER_QUERY_REQUIRED, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-009",
				"errors[%d]description#'%s' is missing from the query string."));
		errorData.put(Constants.PARAMETER_DATATYPE, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-010",
				"errors[%d]description#Incorrect data type '%s' is not valid %s."));
		errorData.put(Constants.PARAMETER_STRING_ENUM, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-012",
				"errors[%d]description#'%s' contains an invalid value."));
		errorData.put(Constants.PARAMETER_INTEGER_MAXLENGTH, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-013",
				"errors[%d]description#'%s' is not in the range of allowed values."));
		errorData.put(Constants.PARAMETER_STRING_MINLENGTH, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-014",
				"errors[%d]description#'%s' can not have more than %d character(s)."));		
		errorData.put(Constants.PARAMETER_STRING_MAXLENGTH, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-015",
				"errors[%d]description#'%s' cant not have fewer than %d character(s)."));
		errorData.put(Constants.PARAMETER_STRING_NUMBER_MINLENGTH, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-029",
				"errors[%d]description#'%s'contains a number outside the range of allowed values. The value submitted may be too large/too small or may include too many digits after the decimal point."));
		errorData.put(Constants.PARAMETER_STRING_NUMBER_MAXLENGTH, ErrorInfo("HTTP/1.1 400 Bad Request",
				"errors[%d]error_code#400-029",
				"errors[%d]description#'%s'contains a number outside the range of allowed values. The value submitted may be too large/too small or may include too many digits after the decimal point."));
	}
	
	private void addParameter(String path,String parameterName,ParameterType parameterType,ParameterDataType parameterDataType,Boolean isRequired,int minLength,int maxLength,int[] statusCodes)
	{
		TreeMap<String,ArrayList<ParameterInfo>> parameterMap;
		ArrayList<ParameterInfo> parameterInfoList;
		ParameterInfo pInfo=new ParameterInfo(parameterName,parameterType,parameterDataType,isRequired,minLength,maxLength,statusCodes);
		
		if(data.containsKey(path))
		{
			parameterMap=(TreeMap<String,ArrayList<ParameterInfo>>)data.get(path);
			parameterInfoList=parameterMap.get(parameterName);
			if(parameterInfoList==null)
				parameterInfoList=new ArrayList<ParameterInfo>();
			parameterMap.put(parameterName, parameterInfoList);
		}
		else
		{
			parameterInfoList=new ArrayList<ParameterInfo>();
			parameterMap=new TreeMap<String,ArrayList<ParameterInfo>>();
			parameterMap.put(parameterName, parameterInfoList);
			data.put(path, parameterMap);
		}
		parameterInfoList.add(pInfo);
		
	}
	
	private String makeTemplateParameterUrl(String url,ArrayList<String>list)
	{
		String[] arr=url.split("/");
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i].startsWith("{") && arr[i].endsWith("}")) 
			{
				if(list!=null)
					list.add(arr[i].replace("{", "").replace("}",""));
				arr[i]="{*}";
			}
		}
		return String.join("/",arr);
	}
	
	public TreeMap<String,ArrayList<ParameterInfo>> getParameterMap(String resourcePath)
	{
		return getParameterMap(resourcePath,null);
	}
	
	public TreeMap<String,ArrayList<ParameterInfo>> getParameterMap(String resourcePath,ArrayList<String> pathColumnsCorrected)
	{
		
		TreeMap<String,ArrayList<ParameterInfo>> paramMap=null;
		resourcePath=resourcePath.toLowerCase();
		if(resourcePath !=null)
		{
			for(Object entry : data.entrySet())
			{
				String path=((Map.Entry<String,ArrayList<ParameterInfo>>) (entry)).getKey();
				if(this.requestTypeConfig.equalsIgnoreCase("GET"))
				{
					ArrayList<String> urlParamList=new ArrayList<String>();
					String path1=makeTemplateParameterUrl(path,urlParamList);
					if(pathColumnsCorrected !=null) {
						pathColumnsCorrected.clear();
					}
					String resourcePath1=makeTemplateParameterUrl(resourcePath,pathColumnsCorrected);
					
					if(resourcePath1.endsWith(path1) && pathColumnsCorrected !=null)
					{
						pathColumnsCorrected.clear();
						pathColumnsCorrected.addAll(urlParamList);
						return (TreeMap<String,ArrayList<ParameterInfo>>) data.get(path);
					}
					else
					{
						String[]path1Arr=path1.split("/");
						ArrayList<String> path1List=new ArrayList<String> (Arrays.asList(path1Arr));
						String[] resourcePath1Arr=resourcePath1.split("/");
						
						ArrayList<String> resourcePath1List=new ArrayList<String>(Arrays.asList(resourcePath1Arr));
						int nResourcePathListIndex=-100;
						for(int i=0;i<path1List.size();i++)
						{
							String part=path1List.get(i);
							if(part.equals("")) continue;
							if(part.equalsIgnoreCase("{*}"))
							{
								if(nResourcePathListIndex !=-100)
									nResourcePathListIndex++;
							}
							else
							{
								int nIndex=resourcePath1List.indexOf(part);
								if(nResourcePathListIndex==-100)nResourcePathListIndex=nIndex;
								if(nIndex!=nResourcePathListIndex || nIndex == -1)break;
								nResourcePathListIndex++;
							}
						}
						if(nResourcePathListIndex >=0)
							return (TreeMap<String,ArrayList<ParameterInfo>>) data.get(path);
					}
				}
				if(resourcePath.endsWith(path))
				{
					return (TreeMap<String,ArrayList<ParameterInfo>>) data.get(path);
				}
			}
		}
		return paramMap;
	}
	
	public String[] getTestCaseIDSplit(Table tbl)
	{
		StringJoiner strTestCases=new StringJoiner("///");
		for(Record record: tbl.getRecords())
			strTestCases.add(record.getField(Configurables.excelTestIDColumn).toString().toUpperCase());
		return strTestCases.toString().split("///");
	}
	
	private static int referenceScenarioCounter=0;
	private String resourceNameConfig="";
	private String testSuiteNameConfig="";
	private String requestTemplateConfig="";
	private String dataTypeOverrideConfig="";
	private String excludedValidations="";
	private String swaggerFile="";
	private String requiredOverrideConfig="";
	private String apiSpecificationUrlConfig="";
	private String resourcePathConfig="";
	private String requestTypeConfig="";
	
	public void generateTestCases(String dataSource,String testSuiteID,Table tbl,String resourceName,String testSuiteName)
	{
		this.resourceNameConfig=resourceName;
		
		//Load filtering criteria
		
		Map<String,String> conditionsMap=new HashMap<String,String>();
		conditionsMap.put("Resource", resourceName);
		conditionsMap.put("Environment", Configurables.gateway_Environment);
		List<Record> testConfigList=Configurables.globalConfigTable.getRecords(conditionsMap).getRecords();
		
		if(testConfigList.size()>0)
		{
			if(testConfigList.get(0).getField("RequestTemplate") !=null)
				this.requestTemplateConfig=testConfigList.get(0).getField("RequestTemplate").toString();
			if(testConfigList.get(0).getField("DataTypeOverride")!=null)
				this.dataTypeOverrideConfig=testConfigList.get(0).getValue("DataTypeOverride").toString();
			if(testConfigList.get(0).getField("ExcludedCheck")!=null)
				this.excludedValidations=testConfigList.get(0).getField("ExcludedCheck").toString();
			if(testConfigList.get(0).getField("SwaggerFile")!=null)
				this.swaggerFile=testConfigList.get(0).getField("SwaggerFile").toString();
			if(testConfigList.get(0).getField("RequiredOverride")!=null)
				this.requiredOverrideConfig=testConfigList.get(0).getField("RequiredOverride").toString();
			if(testConfigList.get(0).getField("ApiSpecificationUrl")!=null)
				this.apiSpecificationUrlConfig=testConfigList.get(0).getField("ApiSpecificationUrl").toString();
			
			//selects appropriate resource path
			
			String baseURI=testConfigList.get(0).getField("BaseURI").toString();
			String resourcePath="Wso2 Resource Path";
			if(baseURI.contains(Config.getProp("tomcatPortNo"))) {
				resourcePath="Tomcat Resource Path";
			}
			if(testConfigList.get(0).getField(resourcePath)!=null)
				this.resourcePathConfig=testConfigList.get(0).getField(resourcePath).toString();
			
			if(testConfigList.get(0).getField("RequestType") !=null)
				this.requestTypeConfig=testConfigList.get(0).getField("RequestType").toString();
		}
		if(testConfigList.get(0).getField("AutoGenerateTCs?")!=null && testConfigList.get(0).getField("AutoGenerateTCs?").toString().equalsIgnoreCase("Y"))
		{
			readSwagger();
		}
		
		List<Record> autoRecordList = new ArrayList<Record>();
		List<Record> records=tbl.getRecords();
		
		for(Record record:records)
		{
			String scenarioName=record.getValue("Scenario_Name");
			if(scenarioName!=null && (scenarioName.endsWith("{{SWAGGER VALIDATION}}")
					|| scenarioName.endsWith("{{SWAGGER VALIDATION*}}")))
			{
				record.getField("Scenario_Name").setValue("(" + String.valueOf(++referenceScenarioCounter) + ") " + scenarioName.replace("{{SWAGGER VALIDATION}}",""));
				referenceScenarioTCCounter=0;
				boolean generateAllTestCases=false;
				if(scenarioName.endsWith("{{SWAGGER VALIDATION*}}")) generateAllTestCases=true;
				autoRecordList.addAll(autogenerateTestCases(tbl,record,generateAllTestCases));
			}
		}
		
		if(autoRecordList != null && autoRecordList.size()>0)
		{
			for(Record autoRecord:autoRecordList)
			{
				tbl.addRecord(autoRecord);
				autoTestcaseMap.put(generateKey(dataSource,testSuiteID,autoRecord.getValue(Configurables.excelTestIDColumn)), autoRecord);
			}
			
			//clear data from prev test suite to support multiple swagger
			requiredOverrideMap.clear();
			datatypeOverrideMap.clear();
			excludedValidationsMap.clear();
		}
	}
	
	public static void writeUsingFileWriter(String data)
	{
		File file=new File("src/test/resources/test-data" + DateTime.now().toString().replace(":",".")+".csv");
		FileWriter fr=null;
		try
		{
			fr=new FileWriter(file);
			fr.write(data);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				fr.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	public static String generateKey(String dataSource,String testSuiteID,String testCaseID)
	{
		return dataSource + "|" + testSuiteID + "|" + testCaseID;
	}
	
	public static Record getRecord(String dataSource,String testSuiteID,String testCaseID)
	{
		return autoTestcaseMap.get(generateKey(dataSource,testSuiteID,testCaseID));
	}
	
	private List<Record> prepareRequiredFieldBlankTestCase(ParameterInfo paramInfo,Record record)
	{
		List<Record> autoRecords=New ArrayList<Record>();
		if(paramInfo.getIsRequired()==true)
		{
			Record autoRecord=new Record();
			String category;
			if(paramInfo.getParameterType()== ParameterType.RequestBodyAttribute)
				category=Constants.PARAMETER_STRING_REQUIRED;
			else if(paramInfo.getParameterType()==ParameterType.RequestHeaderAttribute)
			{
				category=Constatnts.PARAMETER_HEADER_REQUIRED;
				if(record.getField("EXCLUDE HEADER")==null)
					record.add("EXCLUDE HEADER","");
			}
			else if(paramInfo.getParameterType()==ParameterType.RequestQueryAttribute)
				category=Constants.PARAMETER_QUERY_STRING_REQUIRED;
			
			ErrorInfo errInfo=errorData.get(category);
			String paramerterName=paramInfo.getParameterName().toUpperCase();
			String invalidValue="";
			for(String column: record.getColumns())
			{
				if(column.equalsIgnoreCase("TEST CASE ID"))
					autoRecord.add(column,String.valueOf(autoTestCaseIdCounter++));
				else if(column.equalsIgnoreCase("SCENARIO_NAME"))
					autoRecord.add(column,String.format("(" + String.valueOf(referenceScenarioCounter) + "." + String.valueOf(++referenceScenarioTCCounter)+ " Auto) Send Invalid Data with % field missing", paramInfo.getParameterName()));"
				else if(column.equalsIgnoreCase("$" +parameterName))
					{
						autoRecod.add(column,"");
					}
				else if(paramInfo.getParameterType()==ParameterType.RequestBodyAttribute && column.endsWith("EXCLUDE HEADER"))
				{
					autoRecord.add(column,paramInfo.getParameterName());
				}
				else if(column.equalsIgnoreCase("EXPECTED RESULT"))
				{
					autoRecord.add(column,"Error Response");
				}
				else if(column.equalsIgnoreCase("VALIDATESTATUSLINE"))
				{
					autoRecord.add(column,errInfo.getStatusLine());
				}
				else if(column.equalsIgnoreCase("VALIDATEERRORDESCRIPION"))
				{
					String[] paramNameHierarchyArr=paramInfo.getParameterName().split("\\$");
					int size=paramNameHierarchyArr.length;
					String fieldName=paramInfo.getParameterName();
					if(size>0)
						fieldName=paramNameHierarchyArr[size-1];
					autoRecord.add(column,String.format(errInfo.getErrorDescription(), 0,fieldName));
				}
				else if(column.matches("VALIDATION1"))
				
					autoRecord.add(column,String.format(errInfo.getFieldNameValidation(), 0,paramInfo.getParameterName().replace("$",".")));
				else if(column.startsWith("$")==false && column.equals("VALIDATION3"))
					autoRecord.add(column,String.format(errInfo.getAPISpecificationUrl(),0,this.apiSpecificationUrlConfig));
				else if(column.startsWith("$")== false && column.startsWith("VALIDAT"))
					autoRecord.add(column,"");
				else
					autoRecord.add(column,record.getValue(column));
				
			}
			autoRecords.add(autoRecord);
		}
		return autoRecords;
	}
}


