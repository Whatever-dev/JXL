package com.javaexcel.automation.core.utils;

public class ApplicationUrlDetails {
	
	private String applicationArea;
	private String applicationName;
	private String applicationUrl;
	private String environment;
	
	public String getApplicationArea() {
		return applicationArea;
	}
	public void setApplicationArea(String appliationArea) {
		this.applicationArea=applicationArea;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName=applicationName;
	}
	public String getApplicationUrl()
	{
		return applicationUrl;
	}
	public void setApplicationUrl(String applicatioUrl)
	{
		this.applicationUrl=applicationUrl;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment=environment;
	}

}
