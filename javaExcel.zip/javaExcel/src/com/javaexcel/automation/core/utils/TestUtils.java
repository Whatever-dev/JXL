package com.javaexcel.automation.core.utils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.itextpdf.text.pdf.PdfStructTreeController.returnType;
import com.javaexcel.automation.core.data.Config;
import com.javaexcel.automation.core.data.Configurables;
import com.javaexcel.automation.core.data.ITestContext;
import com.javaexcel.automation.core.data.ITestResult;
import com.javaexcel.automation.core.enums.TestFilterType;
import com.javaexcel.automation.core.testngdata.TestNGTest;

public abstract class TestUtils {
	
	private String testName="";
	public static Map<String,String> getMethodParameters(ITestResult result,int componentIndex){
		return getMethodParameters(result.getTestContext(),componentIndex);
	}
	
	public static Map<String,String> getMethodParameters(ITestContext context,int componentIndex){
		Map<String,String> parameters=context.getCurrentXmlTest().getClasses().get(componentIndex).getIncludedMethods().get(0).getAllParameters();
		return parameters;
	}
	public static Map<String,String> getTestParameters(ITestResult result){
		return getTestParameters(result.getTestContext());
	}
	
	public static Map<String,String> getTestParameters(ITestContext context){
		Map<String,String> parameters=context.getCurrentXmlTest().getAllParameters();
		return parameters;
	}
	
	public static int getComponentIndexFromID(String id) {
		return Integer.parseInt(id.split("-")[1])-1;
	}
	
	public static String getStatusString(int status) {
		switch(status) {
		case 1:
				return "Passed";
		case 2:
				return "Failed";
		case 3:
				return "Skipped";
		case 4: 
				return "SUCCESS PERCENTAGE FAILURE";
		case 16:
				return "STARTED";
			default:
				return "UNKNOWN";
		}
	}
	
	public static String getALMStatusString(int status) {
		switch(status) {
		case 1:
				return "Passed";
		case 2:
		case 4:
				return "Failed";
		case 16:
			return "Not Completed";
			default:
				return "No Run";
		}
	}
	
	public static int getStatusFromContext(ITestContext context) {
		int failedComponents=context.getFailedTests().size();
		int  failedConfiguration=context.getFailedConfigurations();
		
		if(failedComponents >0) {
			return 2;
		}else if(failedConfiguration >0) {
			return 3;
		}else {
			return 1;
		}		
	}
	
	public static String getALMStatusFromContext(ITestContext context) {
		return getALMStatusString(getStatusFromContext(context));
	}
	
	public static String createURL(String sourceFilePath,String destinationFilePath) {
		String content="[InternetShortcut]\nURL="+sourceFilePath;
		String finalPath=destinationFilePath+"/results.URL";
		File file=new File(finalPath);
		try {
			FileUtils.writeStringToFile(file, content,Charset.defaultCharset());
		}catch(IOException e) {
			e.printStackTrace();
		}
		return finalPath;
	}
	
	public static TestFilterType getTestFilterType() {
		switch (Configurables.testFilterType.toLowerCase()) {
		case "name":
			default:
				return TestFilterType.Name;
			case "id":
			case "testid":
					return TestFilterType.TestID;
			case "configurationid":
			case "configuration id":
			case "configid":
			case "config id":
				return TestFilterType.ConfigurationID;
				
		}
	}
	
	public static String getInvalidTestName(TestNGTest test,String keyColumn,String keyValue) {
			if(test.getName() != null)
				return "Invalid Test - Name: "+ test.getName();
			if(test.getConfigID()!=null)
				return "Invalid Test - ConfigID:"+ test.getConfigID();
			if(test.getID()!=null)
				return "Invalid test -id:" + test.getID();
			return "Invalid Test -" + keyColumn + ":" + keyValue;
	}
	
	public static String getTestIdentifier(ITestContext context) {
		switch(getTestFilterType()) {
		case Name:
			return context.getCurrentXmlTest().getName();
		case TestID:
			return getTestParameters(context).get("TestID");
		case ConfigurationID:
			return getTestParameters(context).get("ConfigID");
		}
		return null;
	}
	
	//Download the file from ALM to get the Excel Config details
	
	public static String downloadFileFromALM() {
		 int returnValue=-1;
		 try {
			 if(Utils.checkExists(Config.getProp("ALMDownloadExeFile"))
					 && Utils.checkExists(Config.getProp("ALMDomain")) && Utils.checkExists(Config.getProp("ALMProject"))
					 && Utils.checkExists(Config.getProp("ALMUserID"))
					 && Utils.checkExists(Config.getProp("ALMPassword"))
					 && Utils.checkExists(Config.getProp("DownloadExcelFile"))
					 && Utils.checkExists(Config.getProp("ALMOperation"))
					 && Utils.checkExists(Config.getProp("encrptionKey"))) {
			 }
		 
				 
			 }
		 catch (Exception e) {
			// TODO: handle exception
		}
		 return "";
	}
	
	public static List<String> getCustomListeners(){
		String listeners = Config.getProp("CustomListeners", "");
		if(listeners.isEmpty())
			return new ArrayList<>();
		
		return Arrays.asList(listeners.split(","));
	}

}
