package com.javaexcel.automation.core.utils;


import java.io.BufferedWriter;
import java.io.FileOutputStream; import java.io.IOException; 
import java.io.OutputStreamWriter; import java.io.Writer; import java.util.List; 
import java.util.ListIterator;
import com.googlecode.jatl.Html; import com.javaexcel.automation.core.data. Config; 
import com.javaexcel.automation.core.data. TestNGTestData; 
import com.javaexcel.automation.core.listeners.CustomLogger; 
import com.javaexcel.automation.core.testngdata. TestNGClass; 
import com.javaexcel.automation.core. testngdata. TestNGMethod; 
import com.javaexcel.automation.core.testngdata. TestNGSuite; 
import com.javaexcel.automation.core.testngdata. TestNGTest;

public class XMLGenerator {
	
	public static void generateXML (final List<TestNGTestData> testCases) {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("testng.xml"), "utf-8"))){
			new Html(writer) {{
				raw("<?xml version='1.0' encoding='UTF-8' ?>"); 
				raw("<!DOCTYPE suite SYSTEM 'http://testng.org/testng-1.0.dtd'>");
				start("suite").attr("name", "Suite"); 
				start("listeners"); 
				end();
				for(TestNGTestData tc : testCases) { 
					for (String parameter : tc.beforeTestParameters.keySet()) {
						start("parameter").attr("name", parameter, "value",tc.beforeTestParameters.get(parameter)).end();
					}
					start("test").attr("name", tc. testName); 
					start("classes");
					start("test").attr("name", tc. testName); 
					start("classes"); 
					for (int i = 0; i < tc.getNumOfClasses(); i++){
						start("class").attr("name", tc.className[i]); 
						start("methods"); 
						for (int j = 0; j < tc.getNumOfMethods(i); j++){
							System.out.println(tc.getNumOfMethodParameters(i, j)); 
							for (int k = 0; k< tc.getNumOfMethodParameters(i, j); k++) {
								start("parameter").attr("name", tc.methodNames[i][j] + (k+1),"value",tc.methodParameters[i][j][k]).end();
							}
							start("include").attr("name",tc.methodNames[i][j]).end();
						}
						end(); end();
					}
					end(); end();
				}
				endAll();
			}};
			writer.close(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();
		}
	}

}