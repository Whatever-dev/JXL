package com.javaexcel.automation.core.data;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import com.javaexcel.automation.core.utils.PasswordGenerator;
import com.javaexcel.automation.core.utils.Utils;

public class Config {
	
	public static boolean debug=true;
	public static String connectionString;
	private static Map<String,String> properties=new HashMap<>();
	public static void addProps(Map<String,String> inputMap) {
		properties.putAll(inputMap);
	}
	
	public static void addPropsIfAbsent(Map<String,String> inputMap) {
		for(String key: inputMap.keySet()) {
			properties.putIfAbsent(key,inputMap.get(key));
		}
	}
	
	//Get configuration value from testdataconfig or injected parameters
	
	public static String getProp(String key) {
		String keyStr=key.toLowerCase();
		String prop=System.getProperty(key);
		
		if(key.equals("Branch") && prop!=null) {
			return prop;
		}
		
		if(key.equals("Branch") && prop==null) {
			return "N/A";
		}
		if(key.equals("jobName") && prop!=null) {
			return prop;
		}		
		if(key.equals("jenkinsURL") && prop!=null) {
			return prop;
		}		
		if(key.equals("build") && prop!=null) {
			return prop;
		}
		if(!properties.containsKey(keyStr)) {
			return null;
		}
		if(key.equals("Environment") && prop!=null) {
			return prop;
		}
		if(key.equals("API_Name") && prop!=null) {
			if(prop.equalsIgnoreCase("Default")|| prop.equalsIgnoreCase("") || prop.equalsIgnoreCase("$API_Name")) {
				return properties.get(keyStr);
			}else {
				return prop;
			}
		}
		if(key.equals("enableAutoTCs") && prop!=null) {
			return prop;
		}
		if(key.equals("tagName")&& prop!=null) {
			if(Config.getProp("Environment").contains("PROD")) {
				return "Wso2Prod";
			}
			return prop;
		}else {
			if(key.equals("tagName") && Config.getProp("Environment").contains("PROD")) {
				
			}
		}
		if(key.equals("UploadToALM") && prop!=null) {
			return prop;
		}
		if(key.equals("TestFile") && prop!=null && prop.length()>4) {
			return prop;
		}
		return properties.get(keyStr);
		
	}
	
	//Get configuration value from testdataconfig or injected parameters
	
	public static String getProp(String key,String valueIfNull) {
		key=key.toLowerCase();
		if(!properties.containsKey(key)) {
			properties.put(key, valueIfNull);
			return valueIfNull;
		}
		return properties.get(key);
	}
	
	//get configuration value from testdataconfig or injected parameters, then converts it into a boolean value
	public static boolean getBoolProp(String key) {
		return Utils.isAffirmative(getProp(key));
	}
	
	//
	public static boolean getBoolProp(String key,String valueIfNull) {
		return Utils.isAffirmative(getProp(key,valueIfNull));
	}
	
	private static String getPassword() {
		byte[] decodedKey=Base64.getDecoder().decode(Config.getProp("QTPencriptionKey"));
		SecretKey originalKey=new SecretKeySpec(decodedKey,0,decodedKey.length,"AES");
		try {
			return PasswordGenerator.decrypt(Config.getProp("Password"),originalKey);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
