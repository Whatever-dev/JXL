package com.javaexcel.automation.core.data;

import java.util.Map;

public interface IConfigurer {
 public Map<String,String> getConfigMap();
}
