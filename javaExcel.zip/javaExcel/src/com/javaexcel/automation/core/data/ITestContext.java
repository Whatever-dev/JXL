package com.javaexcel.automation.core.data;

import java.util.Date;
import java.util.List;

import org.testng.IAttributes;
import org.testng.IClass;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.xml.XmlTest;

import com.google.inject.Injector;
import com.google.inject.Module;

public interface ITestContext extends IAttributes{
	//name of this test
	public String getName();
	
	public void setName(String name);
	//when test is started
	public Date getStartDate();
	//when test is ended
	public Date getEndDate();
	//return A list of all the tests that run successfully
	public IResultMap getPassedTests();
	//returns all test that were skipped
	public IResultMap getSkippedTests();
	//return a list of all the test that failed but are being ignored based annot
	public IResultMap getFailedButWithinSuccessPercentageTests();
	
	//List of failed testcase
	public IResultMap getFailedTests();
	//group of test that included for this test
	public String[] getIncludedGroups();
	//group of test that excluded
	public String[] getExcludedGroups();
	
	// Report folder
	public String getOutputDirectory();
	//test suite object that was passed to the runner at start-up
	public ISuite getSuite();
	//All the test methods that were run
	public ITestNGMethod[] getAllTestMethods();
	
	//The host where this test was run or null if its local execution
	public String getHost();
	//Retrives information about the successful configuration method invocation
	public IResultMap getPassedConfigurations();
	//Retrives information about the skipped configuration method invocation
	public ITestResult getSkippedConfigurations();
	
	//Retrives information about the failed configuration method invocation
	public ITestResult getFailedConfigurations();
	
	//The current XMLTest
	public XmlTest getCurrentXmlTest();
	
	public List<Module> getGuiceModules(Class<? extends Module> cls);
	public Injector getIngector(List<Module> moduleInstance);
	Injector getInjector(IClass iClass);
	public void addInjector(List<Module>moduleInstance, Injector injector);
	

}
