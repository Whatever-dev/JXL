package com.javaexcel.automation.core.data;

import org.testng.IAttributes;
import org.testng.IClass;
import org.testng.ITestNGMethod;

public interface ITestResult extends IAttributes,Comparable<ITestResult>{
	
	public static final int SUCCESS=1;
	public static final int FAILURE=2;
	public static final int SKIP=3;
	public static final int SUCCESS_PERCENTAGE_FAILURE=4;
	public static final int STARTED=16;
	
	// the status of this result using one of the constance
	public int getStatus();
	public void setStatus(int status);
	
	public ITestNGMethod getMethod();
	
	public Object[] getParameters();
	public void setParameters(Object[] parameters);
	
	public IClass getTestClass();
	
	public Throwable getThrowable();
	public void setThrowable(Throwable throwable);
	
	public long getStartMillis();
	
	public long getEndMillis();
	public void setEndMillis(long millis);
	
	public String getName();
	
	public boolean isSuccess();
	
	public String getHost();
	public Object getInstance();
	
	public String getTestName();
	public String getXmlTestName();
	public String getInstanceName();
	
	public ITestContext getTestContext();

}
