package com.javaexcel.automation.core.data;

import java.util.HashMap;

import com.javaexcel.automation.core.enums.DataInputType;
//import com.javaexcel.automation.core.table.Table;
//import com.javaexcel.automation.core.data.Config;
import com.javaexcel.automation.core.table.Table;

public class Configurables {
	
	//General Config
	public static String projectName=Config.getProp("API_Name","WFG-API-TEST");
	public static String testFileName=Config.getProp("TestFile");
	public static String testsFilePath=Config.getProp("Path","src/test/resources/test-data");
	public static String dataFilePath=Config.getProp("DataFile",testsFilePath);
	public static String componentFilePath=Config.getProp("ComponentFile",testsFilePath);
	public static String testFilterType=Config.getProp("TestFilterType","TestiD");
	
	public static DataInputType dataInputType=DataInputType.parse(Config.getProp("DataInputType","Excel"));
	public static String runID=Config.getProp("RunID");
	public static String jenkinsURL=Config.getProp("jenkinsURL");
	public static boolean parallel=Config.getBoolProp("Parallel");
	public static boolean useJavascriptText=Config.getBoolProp("JavascriptText","Yes");
	public static String uploadDirectory=Config.getProp("UploadDirectory","reports/html");
	public static String lastestBuildDirectory=Config.getProp("LatestUploadDirectory","reports/html/latestBuild");
	public static String screenshotDirectory=Config.getProp("ScreenshotDirectory");
	public static String summaryFile=Config.getProp("SummaryFile");
	public static String threadCount=Config.getProp("ThreadCount");
	public static boolean TestWithMultiConfig=Config.getBoolProp("TestWithMultiConfig","true");
	public static boolean TestScenarioSheet=Config.getBoolProp("TestScenarioSheet","false");
	public static String ScenarioSheetName=Config.getProp("ScenarioSheetName","ScenarioFlow");
	
	public static String excelFile=Config.getProp("ExcelSummaryFile");
	
	public static boolean TestFileWithExeFlag=Config.getBoolProp("TestFileWithExeFlag","true");
	public static String gateway_Environment=Config.getProp("Environment");
	public static String gateway_Resource=Config.getProp("gateway_Resource");
	public static String gateway_version=Config.getProp("gateway_version");
	public static String gateway_resource_Column=Config.getProp("gateway_resource_Column");
	public static String gateway_flag=Config.getProp("gateway_flag","Flag");
	public static String gateway_flag_value=Config.getProp("gateway_flag_value","Y");
	public static String gateway_IncludeInRun=Config.getProp("gateway_IncludeInRun","IncludeInRun");
	public static String gateway_IncludeInRun_value=Config.getProp("gateway_IncludeInRun_value","Y");
	public static String gateway_sheet_ID=Config.getProp("gateway_sheet_ID");
	public static String gateway_ResourceTable=Config.getProp("Resources");
	public static String gateway_EnvTable=Config.getProp("API_Env_Properties");
	public static String gateway_EnvironmentColumnName=Config.getProp("gateway_EnvironmentColumnName");
	public static String gateway_TestConfigSheetName=Config.getProp("gateway_TestConfigSheetName");
	public static Boolean envFlg=true;
	public static Boolean reqFlg=true;
	public static Table globalEnvTable=new Table();
	public static Boolean resourceFlg=true;
	public static Table globalResourceTable=new Table();
	public static Table globalConfigTable=new Table();
	public static Boolean tcQueryFlg=true;
	public static Table globalTCsTable=new Table();
	public static Table globalReqsTable=new Table();
	public static String tcQuery=null;
	public static HashMap<String,Table> testTableMap=new HashMap<String,Table>();
	
	//Local execution
	public static String testCases=Config.getProp("TestCases");
	public static String testIDs=Config.getProp("TestCases");
	public static String testCasesFormQuery=Config.getProp("testCasesFormQuery");
	public static boolean useGrid=Config.getBoolProp("Grid","no");
	public static String gridHubURL=Config.getProp("GridHubUrl");
	public static String testCaseDelimiter=Config.getProp("TestCaseDelimiter","///");
	public static String configIDDelimiter=Config.getProp("ConfigIDDelimiter","\\$");
	
	//Object repository DB
	public static String objectRepositoryPageField=Config.getProp("ObjectPageField");
	public static String objectRepositoryNameField=Config.getProp("ObjectNameField");
	public static String objectRepositoryDescriptionField=Config.getProp("ObjectDescriptionField");
	public static String objectRepositoryTypeField=Config.getProp("ObjectTypeField");
	public static String objectRepositoryContentField=Config.getProp("ObjectContentField");
	public static String objectRepositoryProjectField=Config.getProp("ProjectField");
	public static String objectRepositoryTable=Config.getProp("ObjectTable");
	
	public static String objectRepositoryApplAreaField=Config.getProp("applicationArea");
	public static String objectRepositoryEnvironmentField=Config.getProp("environment_MultiUserInof");
	public static String objectRepositoryApplNameField=Config.getProp("applicationName");
	public static String objectRepositoryRoleField=Config.getProp("role");
	public static String objectRepositoryStatusField=Config.getProp("status");
	public static String userCredentialTable=Config.getProp("userCredentialsTable");
	public static String urlDetailsTable=Config.getProp("urlDetailsTable");
	public static String objectRepositoryParalleLogineField=Config.getProp("paralellLogin");
	
	//Excel test data
	
	public static String excelTestSheet=Config.getProp("TestSheet","Tests");
	public static String excelReqSheet=Config.getProp("Requirements","Requirements");
	public static String excelComponentSheet=Config.getProp("ComponentSheet","Steps");
	public static String excelIdColumn=Config.getProp("IDColumn","ID");
	public static String excelTestsColumn=Config.getProp("TestsColumn","Test Case Name");
	public static String excelTestParentColumn=Config.getProp("TestParentColumn","Test Suite Name");
	public static String excelTestIDColumn=Config.getProp("TestIDColumn","Test Case ID");
	public static String excelTestSuiteIDColumn=Config.getProp("TestSuiteIDColumn","Test Suite ID");
	public static String excelConfigIDColumn=Config.getProp("ConfigIDColumn","Configuration ID");
	public static String excelOptionColumn=Config.getProp("OptionColumn","Options");
	public static String excelDataSourceColumn=Config.getProp("DataSourceColumn","Data Source");
	public static String excelDataIDColumn=Config.getProp("DataIDColumn","Data ID");
	public static String excelMethodColumn=Config.getProp("MethodColumn","Method");
	public static String excelProjectColumn=Config.getProp("ProjectColumn","Project");
	public static String excelPackageColumn=Config.getProp("PackageColumn","Package");
	public static String excelClassColumn=Config.getProp("ClassColumn","Class");
	public static String excelComponentColumn=Config.getProp("ComponentColumn","Steps");
	public static String excelConfigPointerKeyword=Config.getProp("ExcelConfigPointer","ConfigID");
	public static String excelComponentMatchColumn=Config.getProp("ComponentMatchColumn","Test Step ID");
	public static String stepIDColumn=Config.getProp("StepIDColumn","Internal StepId");
	public static String tagName=Config.getProp("tagName","tagName");
	
	//ALM
	public static String almUploadDirectory=Config.getProp("uploaddirectory");
	public static String almAttachTarget=Config.getProp("ALMAttachTarget","run");
	public static String almUrl=Config.getProp("almurl");
	public static String almCredentials=Config.getProp("almcredentials");
	public static String almDomain=Config.getProp("almdomain");
	public static String almProject=Config.getProp("almproject");
	public static String testSetIDs=Config.getProp("TestSetIDs");
	public static String almRunFlagColumn=Config.getProp("RunFlagColumn");
	public static String almTargetFunFlag=Config.getProp("RunFlag");
	public static String almStatusRequirement=Config.getProp("ALMStatus","Any");
	public static String almApplicationIDField=Config.getProp("ALMApplicationIDField");
	
	//Misc
	public static String excelConfigPath=Config.getProp("ExcelConfig");
	public static boolean allComponentsRequiredByDefault=Config.getBoolProp("DefaultRequired","True");
	public static boolean useCustomFireforProfile=Config.getBoolProp("UseCustomFirefoxProfile","No");
	public static boolean updateAutomationDB=Config.getBoolProp("DBStatus","False");
	public static boolean dbReporting=Config.getBoolProp("DBReporting","false");
	public static boolean useDBData=Config.getBoolProp("UseDBData","No");
	public static boolean enableChromePopup=Config.getBoolProp("EnableChromePopUp","false");
	
	//This method updates the configurable property value to the update alue
	//once we updated the configMpa based on different project
	
	public static void updateConfigurablesValue() {
		
		projectName=Config.getProp("API_Name","API-TEST");
		testFileName=Config.getProp("TestFile");
		testsFilePath=Config.getProp("TestFilePath","src/test/resources/test-data/");
		dataFilePath=Config.getProp("DataFile",testsFilePath);
		componentFilePath=Config.getProp("ComponentFile",testsFilePath);
		testFilterType=Config.getProp("TestFilterType","TestiD");
		parallel=Config.getBoolProp("Parallel");
		useJavascriptText=Config.getBoolProp("JavascriptText","Yes");
		uploadDirectory=Config.getProp("UploadDirectory");
		screenshotDirectory=Config.getProp("ScreenshotDirectory");
		summaryFile=Config.getProp("SummaryFile");
		threadCount=Config.getProp("ThreadCount");
		excelFile=Config.getProp("ExcelSummaryFile");
		testCases=Config.getProp("TestCases");
		testCasesFormQuery=Config.getProp("testCasesFormQuery");
		useGrid=Config.getBoolProp("Grid","no");
		gridHubURL=Config.getProp("GridHubUrl");
		testCaseDelimiter=Config.getProp("TestCaseDelimiter","///");
		configIDDelimiter=Config.getProp("ConfigIDDelimiter","\\$");
		objectRepositoryPageField=Config.getProp("ObjectTypeField");
		objectRepositoryNameField=Config.getProp("ObjectNameField");
		objectRepositoryDescriptionField=Config.getProp("ObjectDescriptionField");
		objectRepositoryTypeField=Config.getProp("ObjectTypeField");
		objectRepositoryContentField=Config.getProp("ObjectContentField");
		objectRepositoryProjectField=Config.getProp("ProjectField");
		objectRepositoryTable=Config.getProp("ObjectTable");
		objectRepositoryApplAreaField=Config.getProp("applicationArea");
		objectRepositoryEnvironmentField=Config.getProp("enviroment_MultiUserInfo");
		objectRepositoryApplNameField=Config.getProp("applicationName");
		objectRepositoryRoleField=Config.getProp("role");
		objectRepositoryStatusField=Config.getProp("status");
		userCredentialTable=Config.getProp("userCredentialsTable");
		urlDetailsTable=Config.getProp("urlDetilsTable");
		objectRepositoryParalleLogineField=Config.getProp("paralellLogin");
		
		excelTestSheet=Config.getProp("TestSheet","Tests");
		excelComponentSheet=Config.getProp("ComponentSheet","Test Steps");
		excelIdColumn=Config.getProp("IDColumn","ID");
		excelTestsColumn=Config.getProp("TestsColumn","Test Case Name");
		excelTestParentColumn=Config.getProp("TestParentColumn");
		excelTestIDColumn=Config.getProp("TestIDColumn","Test Case ID");
		excelConfigIDColumn=Config.getProp("ConfigIDColumn","Configuration ID");
		excelOptionColumn=Config.getProp("OptionColumn","Options");
		excelDataSourceColumn=Config.getProp("DataSourceColumn","Data Source");
		excelDataIDColumn=Config.getProp("DataIDColumn","Data ID");
		excelMethodColumn=Config.getProp("MethodColumn","Method");
		excelProjectColumn=Config.getProp("ProjectColumn","Project");
		excelPackageColumn=Config.getProp("PackageColumn","Package");
		excelClassColumn=Config.getProp("ClassColumn","Class");
		excelComponentColumn=Config.getProp("ComponentColumn","Component");
		excelConfigPointerKeyword=Config.getProp("ExcelConfigPointer","ConfigID");
		excelComponentMatchColumn=Config.getProp("ComponentMatchColumn","Internal Test Case Id");
		stepIDColumn=Config.getProp("StepIDColumn","Internal StepId");
		tagName=Config.getProp("tagName","tagName");
		
		//getway
		
		gateway_Environment=Config.getProp("Environment");
		gateway_Resource=Config.getProp("gateway_Resource");
		gateway_version=Config.getProp("gateway_version");
		gateway_resource_Column=Config.getProp("gateway_resource_Column");
		gateway_flag=Config.getProp("gateway_flag");
		gateway_flag_value=Config.getProp("gateway_flag_value");
		gateway_IncludeInRun=Config.getProp("gateway_IncludeInRun");
		gateway_IncludeInRun_value=Config.getProp("gateway_IncludeInRun_value");
		gateway_sheet_ID=Config.getProp("gateway_sheet_ID","Test Suite ID");
		gateway_EnvTable=Config.getProp("gateway_EnvTable","API_Env_Properties");
		gateway_ResourceTable=Config.getProp("gateway_ResourceTable","Resources");
		gateway_EnvironmentColumnName=Config.getProp("gateway_EnvironmentColumnName","Enviroment");
		gateway_TestConfigSheetName=Config.getProp("gateway_TestConfigSheetName","TestConfig");
		
	}
	
	

}
