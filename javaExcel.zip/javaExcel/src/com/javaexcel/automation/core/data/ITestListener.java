package com.javaexcel.automation.core.data;

import org.testng.ITestNGListener;


import com.javaexcel.automation.core.data.ITestResult;

public interface ITestListener extends ITestNGListener{
	
	//Invoke each time before a test will be invoked
	
	void onTestStart(ITestResult result);
	
	public void onTestSuccess(ITestResult result);
	
	public void onTestFailure(ITestResult result);
	
	public void onTestSkipped(ITestResult result);
	
	public void onTestFailedButWithinSuccessPercentage(ITestResult result);
	
	public void onStart(ITestContext context);
	
	public void onFinish(ITestContext context);
	

}
