package com.javaexcel.automation.core.execution;

public interface ITestManager {
	void execute() throws Exception;
}
