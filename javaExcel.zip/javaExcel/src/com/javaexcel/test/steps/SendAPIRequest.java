package com.javaexcel.test.steps;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument.Config;
import org.junit.Test;

import com.itextpdf.xmp.impl.Utils;
import com.javaexcel.automation.core.data.Configurables;
import com.javaexcel.automation.core.utils.RestClient;
import com.javaexcel.tests.base.APITestBase;

public class SendAPIRequest extends APITestBase{
	
	String dataFilePath=System.getProperty("user.dir");
	String responseFolder=Config.getProp("UploadDirectory");
	String testRunId=Configurables.runID;
	String cr_response_header_id;
	String contentType="application/json";
	
	@Test(dataProvider ="methodparameters")
	public void sendRequest(Map<String,String> params)throws Exception{
		String strCertificatePath=dataFilePath + "/" + params.get("CertificatePath");
		String strCertiPass=params.get("CertificatePassword");
		String strRootCerti=dataFilePath +"/" + params.get("RootCertificatePath");
		String strRootPass=params.get("RootPassword");
		String tc_id=params.get("test suite id") + "_" + params.get("test case id");
		String requestPath="reports/json/request/" + tc_id + ".json";
		String responseXMLDataPath="reports/json/response/" + tc_id+".json";
		
		File responsedestinationpath=new File(responseXMLDataPath);
		if(!responsedestinationpath.exists()) {
			responsedestinationpath.mkdir();
		}
		
		RestClient rs=new RestClient();
		String resourcePath=params.get("Wso2 Resource Path");
		if (params.get("BaseURI").contains(Config.getProp("tomcatPortNo"))) {
			resourcePath=params.get("Tomcat Resouce Path");
		}
		
		if(params.get("Override Resouce Path")!=null && !params.get("Override Resouce Path").equals("")) {
			resourcePath=params.get("Override Resource Path");
		}
		if(params.get("Add to Path")!=null && !params.get("Add to Path").equals("")) {
			resourcePath=resourcePath+params.get("Add to Path");
		}
		String baseURI="";
		if(params.get("Override Base URI")!= null && !params.get("Override Base URI").equals("")) {
			baseURI=params.get("Override Base URI");
		} else {
			baseURI=params.get("BaseURI");
		}
		String uri=baseURI+resourcePath;
		
		//set response header id for chained request
		cr_response_header_id="reports/json/response/" + tc_id+"_header.json";
		
		//retrieve header values
		
		String headerValue=new String();
		headerValue=filterParam("header",params);
		if(!System.getProperty("gatewayEntityID").equals("")) {
			Pattern pattern=Pattern.compile("gateway-entity-id#(.*?)\\||gateway-entity-id(.*)",Pattern.CASE_INSENSITIVE);
			Matcher matcher=pattern.matcher(headerValue);
			if(matcher.find())
			{
				headerValue=headerValue.replaceAll(matcher.group(0).replace("|", ""),"gateway-entity-id#"+System.getProperty("getwayEntityID"));
			}
		}
		if(!System.getProperty("gatewayUserID").equals("")) {
			Pattern pattern=Pattern.compile("gateway-user-id#(.*?)\\||gateway-user-id#(.*)",Pattern.CASE_INSENSITIVE);
			Matcher matcher=pattern.matcher(headerValue);
			if(matcher.find()) {
				headerValue=headerValue.replaceAll(matcher.group(0).replace("|",""),"gateway-user-id#"+System.getProperty("gatewayUserID"));
			}
		}
		
		// add default content-type to header
		headerValue=headerValue+"|Content-Type#"+contentType;
		
		//remove excluded header
		headerValue=removeExcludedHeader(params,headerValue);
		
		String queryParam=param.get("query params");
		if(queryParam==null || queryParam=="") {
			queryParam="";
		}else {
			queryParam=Utils.processKeywords(queryParam);
			String[] paramsArr=null;
			Map<String,String> qParamMap=new LinkedHashMap<>();
			
			if(queryParam.contains("&")) {
				paramsArr=queryParam.split("&");
				for(int i=0;i<paramsArr.length;i++) {
					if(i>0)
						qParamMap.put("&"+paramsArr[i].split("=")[0],paramsArr[i].split("=")[1]);
					else
						qParamMap.put(paramsArr[i].split("=")[0],paramsArr[i].split("=")[1] );
				}
			}else {
				qParamMap.put(queryParam.split("=")[0],queryParam.split("=")[1]);
			}
			
			queryParam=processQueryParams(qParamMap);
		}
		//retrieve chained request data
		GenerateJSONFile gj=new GenerateJSONFile();
		gj.getChainedRequestDataHeader(params);
		gj.getChainedRequestDataBody(params);
		
		//update header to invalid value if appliation
		//Override header
		
		headerValue=updateHeaderValue(params,headerValue);
		//Add new header at TC level as needed
		headerValue=addNewHeaderValue(params,headerValue);
		
		//Retrieve the API Call
		
		String request_type=params.get("requesttype");
		
		//retrieve overriden request-type from data sheet
		String overriddenMethod=filterParam("override method",params);
		if(!overriddenMethod.equals("")) {
			request_type=overriddenMethod;
		}
		
		//Process resource path params including chained request data used in resource path
		Map<String,String> resource_params=processResourcePath("#",params);
		
		String authToken=null;
		if(!System.getProperty("Authentication_Key").equals(""))
		{
			authToken=System.getProperty("Authentication_Key");
		}
		else
		{
			String ver=params.get("Version");
			authToken=params.get("Auth Key"+ver);
		}
		//Override auth token if req
		if(params.get("Override Auth Token")!=null && !params.get("Override Auth Token").equals("")) {
			authToken=params.get("Override Auth Token").trim();
			if(authToken.contains("#") && !authToken.contains("#body")) {
				authToken=Utils.processAuthToken(authToken);
			}
			
			System.out.println("Overwirting auth token with :" +authToken);
		}
		if(!authToken.contains("Basic")) {
			authToken="Basic "+authToekn;
		}
		
		//Override scope
		String scopeOverride=Config.getProp("API_Scopes");
		if(params.get("Override Scope")!=null && !params.get("Override Scope").equals("")) {
			scopeOverride=params.get("Override Scope");
		}
		
		if(request_type.equals("GET")) {
			rs.postDataToServer(cr_response_header_id,resource_params,queryParam,request_type,uri,"",responseXMLDataPath,strCertificatePath,strCertiPass,strRootCerti,strRootPass,headerValue,params.get("TOKEN_URL"),authToken,contentType,scopeOverride);
			//reporter.log
			System.out.println("<details> <summary> View Request Header</summary><p style=\"font-size:11px\">" +rs.headersStr+"</p></details>");
		}else
		{
			if(request_type.equals("PATCH")) {
				rs.postDataToServer(cr_response_header_id,resource_params,queryParam,request_type,uri,requestPath,responseXMLDataPath,strCertificatePath,strCertiPass,strRootCerti,strRootPass,headerValue,params.get("TOKEN_URL"),authToken,contentType,scopeOverride);

			}else if(request_type.equals("DELETE")) {
					rs.postDataToServer(cr_response_header_id,resource_params,queryParam,request_type,uri,"",responseXMLDataPath,strCertificatePath,strCertiPass,strRootCerti,strRootPass,headerValue,params.get("TOKEN_URL"),authToken,contentType,scopeOverride);
				}
			else if(request_type.equals("POST")) {
				rs.postDataToServer(cr_response_header_id,resource_params,queryParam,request_type,uri,requestPath,responseXMLDataPath,strCertificatePath,strCertiPass,strRootCerti,strRootPass,headerValue,params.get("TOKEN_URL"),authToken,contentType,scopeOverride);
			
			}	else if(request_type.equals("PUT")) {
				rs.postDataToServer(cr_response_header_id,resource_params,queryParam,request_type,uri,requestPath,responseXMLDataPath,strCertificatePath,strCertiPass,strRootCerti,strRootPass,headerValue,params.get("TOKEN_URL"),authToken,contentType,scopeOverride);
			
			}else {
				System.err.println("Error Invalid HTTP method used "+ request_type);
			}
			
			//log report
			System.out.println("<details> <summary> View Request Headers</summary><p style=\"font-size:11px\"><pre>"+rs.headerStr+"</pre></p></details>");
			System.out.println("<details> <summary> View Request Headers</summary><p style=\"font-size:11px\"><pre>"+StringEscapeUtils.escapeHtml(rs.reqBodyHTML)+"</pre></p></details>");
		}
	}

	public String removeExcludedHeaders(Map<String,String>params,String headers) {
		String excludedHeaders=filterParam("exclude header",params);
		String excludedHeaderArr[]=excludedHeaders.split("\\|");
		for(String updatedStr : excludedHeaderArr) {
			if(!excludedHeaders.equals("")) {
				String header="excluded-header_"+updatedStr.split("#")[0].trim();
				headers=headers.replace(updatedStr, header);
			}
		}
		return headers;
	}
	
	//add new headers at TC level as needed
	public String addNewHeaderValue(Map<String,String> params,String headers) {
		String allHeaderStrs[]=headers.split("\\|");
		String newHeaders=filterParam("add header",params);
		String newHeaderStrs[]=newHeaders.split("\\|");
		
		for(String updatedStr : newHeaderStrs) {
			if(!newHeaders.equals("")) {
				String header=updatedStr.split("#")[0].trim();
				String value=updatedStr.split("#")[1].trim();
				if(value.equals("{{EMPTY}}")) {
					value="";
				}
				value=Utils.processKeywords(value);
				HashMap<String,String> hdrMap=new HashMap<>();
				
				if(updatedStr.split("#")[0].length()>1) {
					hdrMap.put(header.trim(),value.trim());
				}
				for(Object str:hdrMap.keySet().toArray()) {
					headers=headers+"|" +str+hdrMap.get(str);
				}
			}
		}
		return headers;
	}
	
	public String updateHeaderValue(Map<String, String> params,String headers) {
		String headerStrs[]=headers.split("\\|");
		String updatedHeaders=filterParam("override header",params);
		String updatedHeaderStrs[]=updatedHeaders.split("\\|");
		
		if(updatedHeaders.contains("#body")|| updatedHeaders.contains("#header")) {
			try {
				
				if(updatedHeaders.contains("Authorization")) {
					updatedHeaders=filterParam("Override header", params);
					updatedHeaders=updatedHeaders.split("#")[0]+"#Bearer "+ updatedHeaders.split("#")[1];
					updatedHeaderStrs=updatedHeaders.split("\\|");
				}
				else {
					updatedHeaders=filterParam("override header",params);
					updatedHeaderStrs=updatedHeaders.split("\\|");
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		for(String updatedStr : updatedHeaderStrs) {
			if(!updatedHeaders.equals("")) {
				String header=updatedStr.split("#")[0].trim();
				String value=updatedStr.split("#")[1].trim();
				
				if(value.equals("{{EMPTY}}")) {
					value="";
				} 
				value=Utils.processKeywords(value);
				HashMap<String, String> hdrMap=new HashMap<>();
				
				for(int i=0;i<headerStrs.length;i++) {
					if(headerStrs[i].split("#")[0].equals(header)) {
						hdrMap.put(header.trim(),value.trim());
						
					}
					else if(headerStrs[i].split("#").length==1) {
						hdrMap.put(headerStrs[i].split("#")[0].trim(),"");
					}
					else {
						hdrMap.put(headerStrs[i].split("#")[0].trim(),headerStrs[i].split("#")[1].trim());
					}
				}
				headers=(hdrMap.entrySet().toString().replaceAll(",","\\|").replace("[","").replace("]","").replace("| ","|"));
				for(Object str : hdrMap.keySet().toArray()) {
					headers=headers.replaceAll(str+"=",str+"#");
				}
				
			}
		}
		return headers;
	}
	
	public static String filterParam(String filter,Map<String,String>params)
	{
		Set<String> set=params.keySet().stream()
				.filter(s -> s.startsWith(filter))
				.collect(Collectors.toSet());
		StringJoiner headerJoiner= new StringJoiner("|");
		for (String s : set) {
			if(params.get(s).length()>0) {
				headerJoiner.add(params.get(s));
			}
		}
		String filterValue=headerJoiner.toString();
		return filterValue;
	}
	
	//process resource path including chained request data
	public static Map<String ,String> processResourcePath(String filter,Map<String,String> params) throws IOException
	{
		Map<String,String> resourceVars=new HashMap<String,String>();
		Set<String> set=params.keySet().stream()
				.filter(s -> s.startsWith(filter))
				.collect(Collectors.toSet());
		for(String s : set) {
			String updatedStr="";
			try {
				if(params.get(s)!=null && params.get(s)!= "" & params.get(s).contains("header_")) {
					updatedStr=Utils.getChainedRequestDataHeader(params.get(s));
					resourceVars.put(s, updatedStr);
				}else if(params.get(s)!=null && params.get(s)!= "" & params.get(s).contains("body_")) {
					updatedStr=Utils.getChainedRequestDataBody(params.get(s).replace("\"", ""));
					resourceVars.put(s, updatedStr);
				}else if(params.get(s)!= null && params.get(s)!="") {
					resourceVars.put(s, params.get(s));
				}
			}
			catch(Exception e) {
				System.err.println("Error reading input param in the resource path -" + s + " Undefined or data not found" + e.getMessage());
			}
		}
		return resourceVars;
	}
	
	public static String processQueryParams(Map<String, String>params) throws IOException
	{
		Map<String,String> queryParams=new HashMap<String,String>();
		Set<String> set=params.keySet();
		for(String s : set) {
			String updatedStr="";
			try {
				if(params.get(s)!=null && params.get(s)!= "" & params.get(s).contains("header_")) {
					updatedStr=Utils.getChainedRequestDataHeader(params.get(s));
					queryParams.put(s, updatedStr);
				}else if(params.get(s)!=null && params.get(s)!= "" & params.get(s).contains("body_")) {
					updatedStr=Utils.getChainedRequestDataBody(params.get(s).replace("\"", ""));
					queryParams.put(s, updatedStr);
				}else if(params.get(s)!= null && params.get(s)!="") {
					queryParams.put(s, params.get(s));
				}
			}
			catch(Exception e) {
				System.err.println("Error reading input param in the resource path -" + s + " Undefined or data not found" + e.getMessage());
			}
		}
		String queryParamsStr="";
		for (String s : set){
			queryParamsStr=queryParams+s+"="+queryParams.get(s).replaceAll("\"","");
		}
		return queryParamsStr;
		
	}
}
