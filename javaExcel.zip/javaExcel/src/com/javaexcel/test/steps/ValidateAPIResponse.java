package com.javaexcel.test.steps;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument.Config;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;
import org.junit.Assert;
import org.junit.Test;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.text.List;
import com.javaexcel.automation.core.utils.RestClient;
import com.javaexcel.tests.base.APITestBase;

public class ValidateAPIResponse extends APITestBase {
	
	public SoftAssert sa=new SoftAssert();
	String actValStr=null;
	String defaultExpVal="NULL";
	String assertResultsHdrsConsole="";
	public String gExpKey="";
	public long RT=RestClient.elapsedTime;
	public String actualSortedString="";
	
	@SuppressWarnings("unchecked")
	@Test(dataProvider ="methodparameters")
	public void validateAPIResponse(Map<String,String> params)throws FileNotFoundException,IOException,ParseException
	{
		try {
			int sleep=Integer.parseInt(Config.getProp("sleep"));
			TimeUnit.SECONDS.sleep(sleep);
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		HashMap<String,String> ModifyNodeValue=new HashMap<String,String>();
		String tc_id=params.get("test suite id")+ "_"+ params.get("test case id");
		String responseJsonDataPath="reports/json/response/" + tc_id+ ".json";
		boolean fileBodyExist=false;
		JsonNode jsonNode=null;
		
		//updated validation
		
		try {
			File jsonFile=new File(responseJsonDataPath);
			if(jsonFile.exists()) {
				jsonNode=new ObjectMapper().readTree(jsonFile);
				fileBodyExist=true;
			}
		}catch(Exception e) {
			System.err.println("Error reading/writing response dta");
			//reporter
			System.out.println("<details open> <summary> View API Response </summary><p style=\"font-size:11px\"> Status Code: " + RestClient.statusCode.trim()+"<br>Response time (ms): "+RestClient.elaspedTime+"<br><pre>"+"Response Body: "+ Jsoup.parse(RestClient.resBodyHTML).text()+"</pre></p></details>");
			Assert.fail();
		}
		
		String assertResults="";
		String assertResultsConsole="";
		String status;
		String tmp="";
		Boolean assertFlg=false;
		String jsonStr;
		String file;
		JSONParser parser=new JSONParser();
		JSONArray array=new JSONArray();
		File tempFile=new File(responseJsonDataPath);
		boolean fileExist=tempFile.isFile();
		
		if(fileExist) {
			Object object=parser.parse(new FileReader(responseJsonDataPath));
			array.add(object);
		}
		
		file = array.toString();
		if(!file.equals("{}") && !file.equals(null)){
			assertFlg=true;
		}  
		else {
			file="";
		}
		
		String statusCode =RestClient.statusCode.trim();
		jsonStr=StringEscapeUtils.unescapeJava(RestClient.prettyPrint(file,false));
		
		//Reporter
		System.out.println("<details> <summary> View Response Headers</summary><p style=\"font-size:11px\"><pre>" +RestClient.resHeadersHTLM +"</pre></p></details>");
		System.out.println("<details open> <summary> View API Response</summary><p style=\"font-size:11px\">Status Code: "+statusCode+"<br>Response Time (ms):"+RestClient.elapsedTime+"<br><pre>"+jsonStr+"</pre></p></details>");
		System.out.println("<details> <summary> Expected Result</summary><p style=\"font-size:11px\">"+params.get("expected result")+"</p></details>");
	// validate response headers
		String HeaderValidations=validateResHeaders(params);
		if(params.get("ValidateStatusLine")==null || params.get("ValidateStatusLine")=="" & params.get("VAlidateStatusCode")!=null) {
			RestClient.expectedStatus=params.get("ValidateStatusCode").replace("200","200 OK").replace("400","400 Bad Request")
					.replace("201", "201 Created").replace("406","406 Not Acceptable").replace("403","403 Forbidden")
					.replace("500", "500 Internal Server Error").replace("401", "401 Unauthorized").replace("404","404 Not Found");
		}else
		{
			RestClient.expectedStatus=params.get("ValidateStatusLine").replace("HTTP/1.1 ", "");
		}
		
		//Validate response body
		
		file=file.replaceAll("\\\\/", "/").replaceAll("]", "").replace("[","").replace("https:", "https$").replace("{\"\":", "").replaceAll("errors\":","");
		
		String[] keysplit=file.split(",");
		String [] keystemp= {};
		
		for(int i=0;i<keysplit.length;i++)
		{
			String val="";
			String key="";
			try {
				keystemp=keysplit[i].split(":");
				
				if(keystemp[0]!=null && assertFlg) {
					key=keystemp[0].replace("\"", "").replace("{","").replace("[{","").replace("}", "");
				}
				else {
					keystemp[0]="NULL";
				}
				
				if(keystemp.length>1) {
					val=keystemp[1].replace("\"","").replace("{","").replace("}","").replace("https$","https:");
				}
				
				ModifyNodeValue.put(key, val);
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		
		String[] sr=params.keySet().toString().split(", |=");
		List<String> currentValidations=new ArrayList<>();
		
		//set validation scope
		
		for(int i=0;i<sr.length;i++)
		{
			if(sr[i].contains("Validations") || sr[i].contains("Validations") || sr[i].contains("validate") && !sr[i].contains("validateheader"))
			{
				currentValidations.add(sr[i]);
			}
		}
		
		//Test assertions block
		for(String key:currentValidations)
		{
			if(!params.get(key).equals("")&& params.get(key).contains("#") && fileBodyExist && !params.get(key).contains("$OR") && !params.get(key).contains("NOTEXIST") && !params.get(key).contains("SORT"))
			{
				try {
					actValStr=null;
					String expvalue=(params.get(key)).split("#")[1];
					
					if(expvalue.contains("header_") || expvalue.contains("body_")) {
						expvalue=processChainedData(expvalue);
					}
					if(expvalue.equalsIgnoreCase("{{$Environment}}")) {
						expvalue=TestManager.envName;
					}
					if(expvalue.equalsIgnoreCase("$AssertCertificate") && TestManager.envName.contains("DEV") || expvalue.equalsIgnoreCase("$AssertCertificate") && TestManager.envName.contains("SANDBOX")) {
						expvalue="NOT TESTED";
						
					}
					else if(expvalue.equalsIgnoreCase("$AssertCertificate")) {
						expvalue="true";
					}
					if(expvalue.equalsIgnoreCase("$AssertEnvironment") && TestManager.envName.toUpperCase().contains("DEV")|| expvalue.equalsIgnoreCase("$AssertEnvironment") && TestManager.envName.toUpperCase().contains("SANDBOX")) {
						expvalue="SANDBOX";
					}
					if(expvalue.equalsIgnoreCase("$AssertEnvironment") && TestManager.envName.toUpperCase().contains("VALIDATION")|| expvalue.equalsIgnoreCase("$AssertEnvironment") && TestManager.envName.toUpperCase().contains("SANDBOX")) {
						expvalue="VALIDATION";
					}
					if(expvalue.equalsIgnoreCase("$AssertEnvironment") && TestManager.envName.toUpperCase().contains("PROD")|| expvalue.equalsIgnoreCase("$AssertEnvironment") && TestManager.envName.toUpperCase().contains("SANDBOX")) {
						expvalue="PRODUCTION";
					}					
					if(expvalue.equalsIgnoreCase("AssertTodayDate")) {
						String pattern="MM/dd/yyyy";
						SimpleDateFormat simpleDateFormat=new SimpleDateFormat(pattern);
						String date=simpleDateFormat.format(new Date());
						expvalue=date;
					}
					String fieldName=(params.get(key)).split("#")[0];
					String expkey=(params.get(key)).split("#")[0];
					
					String actval=parseResponseFile("",jsonNode,expkey,expvalue,"",0);
					try {
						if(actval !=null) {
							
						}
						if(!expvalue.contains("\"")) {
							actval=actval.replace("\"","");
						}
						if(actval!=null && actval.contains(",")) {
							actval=actval.replace("\\\\\\\\q", "").trim().replaceAll(" +"," ");
						}
						else if(actval !=null && !actval.contains(",")) {
							actval=actval.replace("\\\\q", "").trim().replaceAll(" +"," ");
						}
						expkey=expkey.trim().replaceAll(" +"," ");
					}catch(Exception e) {
						e.getMessage();
					}
					
					sa.assertEquals(actval,expvalue,"Unexpected field value for \'"+ expkey +"\'");
					
					if(expvalue.equals(actval))
						status="PASS";
					else
						status="FAIL";
					
					assertResultsConsole=assertResultsConsole + "Field:Value for "+ fieldName +" - Expected:" +expvalue +", Actual: "+ actval +"  "+status+ "||";
					
					if(status.equalsIgnoreCase("FAIL")) {
						tmp=setFontColor("FIELD:VALUE for"+ fieldName + " - Expected:"+ expvalue+ ", Actual: "+ actval+ "   "+ status,"red");
					}else {
						tmp=setFontColor("FIELD:VALUE for"+ fieldName + " - Expected:"+ expvalue+ ", Actual: "+ actval+ "   "+ status,"green");
					}
					assertResults=assertResults+tmp;
				}catch(Exception e) {}
			}
			
			//Assertions for key value pair with or conditions
			if(!params.get(key).equals("") && params.get(key).contains("#$OR{") && fileBodyExist)
			{
				try {
					actValStr=null;
					String expvalue=(params.get(key)).split("#")[1];
					
					if(expvalue.contains("header_") || expvalue.contains("body_")) {
						expvalue=processChainedData(expvalue);
					}
					if(expvalue.contains("$OR{")) {
						expvalue=expvalue.replace("$OR{", "").replaceAll("}", "");
					}
					String fieldName=(params.get(key)).split("#")[0];
					String expkey=(params.get(key)).split("#")[0];
					
					String actval=parseResponseFile("",jsonNode,expkey,expvalue,"$OR",0);
					try {
						if(actval!=null) {
							actval=actval.replace(".00", ".0");
						}
						if(!expvalue.contains("\"")) {
							actval=actval.replace("\"", "");
						}
						if(actval!=null && actval.contains(",")) {
							actval=actval.trim().replaceAll(" +", " ");
						}else if(actval !=null && !actval.contains(",")) {
							actval=actval.trim().replaceAll(" +"," ");
						}
						expkey=expkey.trim().replaceAll(" +", " ");
					}catch(Exception e) {
						e.getMessage();
					}
					
					String expArr[]=expvalue.split(",");
					String temp="";
					for(String str: expArr) {
						if(actval.equals(str))
							temp=str.trim();
					}
					sa.assertEquals(actval,temp,"Unexpected field vaue for \'"+ expkey +"\'");
					if(temp.equals(actval))
						status="PASS";
					else
						status="FAIL";
					
					assertResultsConsole=assertResultsConsole + "FIELD:VALUE with OR condition for "+ fieldName + " - Expected (OR):" + expvalue +", Actual: "+ actval + "   "+ status+ "||";
					
					if(status.equalsIgnoreCase("FAIL")) {
						tmp=setFontColor("FIELD:VALUE for"+ fieldName + " - Expected:"+ expvalue+ ", Actual: "+ expvalue+ "   "+ status,"red");
					}else {
						tmp=setFontColor("FIELD:VALUE for"+ fieldName + " - Expected:"+ expvalue+ ", Actual: "+ actval+ "   "+ status,"green");
					}
					assertResults=assertResults+tmp;
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
			
			//Assertions for key value pair with or conditions
			if(!params.get(key).equals("") && params.get(key).contains("#$ORALL{") && fileBodyExist)
			{
				try {
					actValStr=null;
					String expvalue=(params.get(key)).split("#")[1];
					
					if(expvalue.contains("header_") || expvalue.contains("body_")) {
						expvalue=processChainedData(expvalue);
					}
					if(expvalue.contains("$ORALL{")) {
						expvalue=expvalue.replace("$ORALL{", "").replaceAll("}", "");
					}
					String fieldName=(params.get(key)).split("#")[0];
					String expkey=(params.get(key)).split("#")[0];
					
					String actval=parseResponseFile("",jsonNode,expkey,expvalue,"ORALL",0);
					try {
						if(actval!=null) {
							actval=actval.replace(".00", ".0");
						}
						if(!expvalue.contains("\"")) {
							actval=actval.replace("\"", "");
						}
						if(actval!=null && actval.contains(",")) {
							actval=actval.trim().replaceAll(" +", " ");
						}else if(actval !=null && !actval.contains(",")) {
							actval=actval.trim().replaceAll(" +"," ");
						}
						expkey=expkey.trim().replaceAll(" +", " ");
					}catch(Exception e) {
						e.getMessage();
					}
					
				/*	String expArr[]=expvalue.split(",");
					String temp="";
					for(String str: expArr) {
						if(actval.equals(str))
							temp=str.trim();
					}*/
					//sa.assertEquals(actval,temp,"Unexpected field vaue for \'"+ expkey +"\'");
					if("PASS".equals(actval))
						status="PASS";
					else
						status="FAIL";
					
					assertResultsConsole=assertResultsConsole + "FIELD:VALUE with ORALL condition for "+ fieldName + " - Expected (OR):" + expvalue +", Actual: "+ actval + "   "+ status+ "||";
					
					if(status.equalsIgnoreCase("FAIL")) {
						tmp=setFontColor("FIELD:VALUE for"+ fieldName + " - Expected:"+ expvalue+ ", Actual: "+ expvalue+ "   "+ status,"red");
					}else {
						tmp=setFontColor("FIELD:VALUE for"+ fieldName + " - Expected:"+ expvalue+ ", Actual: "+ actval+ "   "+ status,"green");
					}
					assertResults=assertResults+tmp;
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
			
			if(!params.get(key).equals("")&& params.get(key).contains("$SORT")&&fileBodyExist) {
				
				try {
					
					actValStr=null;
					String sortType="ASCEND";
					String expvalue=(params.get(key)).split("#")[1].split("\\$")[0];
					
					if(expvalue.contains("header_")|| expvalue.contains("body_")) {
						expvalue=processChainedData(expvalue);
					}
					String fieldName=(params.get(key)).split("#")[0]+expvalue;
					String expkey=(params.get(key)).split("#")[0];
					
					String actval=parseResponseFile("",jsonNode,expkey,expvalue,"SORT",0);
					
					String actualSort[]=actualSortedString.split(",");
					String expectedSort[]=actualSortedString.split(",");
					if(params.get(key).contains("ASCEND")) {
						Arrays.sort(expectedSort);
					}else {
						Arrays.sort(expectedSort,Collections.reverseOrder());
						sortType="DESCEND";
					}
					if(Arrays.equals(actualSort, expectedSort) && actualSort.length>1) {
						actval="true";
					}else {
						actval="false";
						if(!(actualSort.length>1)) {
							sa.fail("Empty Array! Unpected API Response");
						}
					}
					expvalue="true";
					
					if("true".equals(actval))
						status="PASS";
					else
						status="FAIL";
					assertResultsConsole=assertResultsConsole+sortType+" SORT validation for "+ fieldName + " -Expected: "+expvalue + ", Actual: "+ actval + "    "+ status + "||";
					if(status.equalsIgnoreCase("FAIL")) {
						tmp=setFontColor("FIELD:SORT Validation for"+ fieldName + " - Expected:"+ expvalue+ ", Actual: "+ expvalue+ "   "+ status,"red");
					}else {
						tmp=setFontColor("FIELD:SORT Validation for"+ fieldName + " - Expected:"+ expvalue+ ", Actual: "+ actval+ "   "+ status,"green");
					}
					assertResults=assertResults+tmp;
				}catch(Exception e) {}
			}
			
			//Pattern matching
		
		}
	}
	
}
