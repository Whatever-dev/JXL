package com.javaexcel.tests.base;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.testng.annotations.DataProvider;
import org.testng.internal.annotations.ITest;


import com.javaexcel.automation.core.data.Config;
import com.javaexcel.automation.core.data.Configurables;
import com.javaexcel.automation.core.data.ITestContext;
import com.javaexcel.automation.core.data.MultiUserInfo;
import com.javaexcel.automation.core.execution.Main;
import com.javaexcel.automation.core.utils.TestUtils;
import com.javaexcel.automation.core.utils.Utils;

public abstract class TestBase implements ITest{
		protected static Integer threadCount=0;
		protected MultiUserInfo multiUserInfo=new MultiUserInfo();
		protected String projectName;
		public static Map<String,Map<String,String>> configDetalsProjectWise=new HashMap<>();
		protected ThreadLocal<Integer> threadID=new ThreadLocal<Integer>();
		protected ThreadLocal<Map<String,String>> sharedData=new ThreadLocal<Map<String,String>>();
		private ThreadLocal<String> testName=new ThreadLocal<>();
		
		public void setSharedData(String key,String value) {
			sharedData.get().put(key,value);
		}
		public String getSharedData(String key) {
			return sharedData.get().get(key);
		}
		
		//TestNG Data provider that returns the parameters of the current test as a case-insensitive tree map
		
		@DataProvider(name="testparameters")
		public Object[][] getTestParameters(ITestContext context){
			Map<String,String> parameters=TestUtils.getTestParameters(context);
			Map<String,String> newParameters=new TreeMap<String,String>(String.CASE_INSENSITIVE_ORDER);
			newParameters.putAll(parameters);
			return new Object[][] {{
				newParameters}};
			}
		
		@DataProvider(name="methodParamets")
		public Object[][]getParameters(ITestContext context){
			Map<String,String> newParameters = (Map<String,String>) getTestParameters(context)[0][0];
			Map<String,String>methodParameters=TestUtils.getMethodParameters(context,Main.componentIndex.get());
			newParameters.putAll(methodParameters);
			
			return new Object[][] {{
				newParameters
			}};
		 }
		
		@DataProvider(name="methodparametersmulti")
		public Object[][] getParametersMulti(ITestContext context){
			Map<String,String> parameters=(Map<String,String>)getParameters(context)[0][0];
			List<Map<String,String>> newParameters=new ArrayList<Map<String,String>>();
			
			int index;
			String key;
			for (String param : parameters.keySet()) {
				if(param.contains("_$")) {
					String[] keys=param.split("_\\$");
					index=Integer.parseInt(keys[1]);
					key=keys[0];
				}else {
					index=0;
					key=param;
				}
				while(index > newParameters.size() -1) {
					newParameters.add(new TreeMap<String,String>(String.CASE_INSENSITIVE_ORDER));
				}
				String value=parameters.get(param);
				newParameters.get(index).put(key, value);
			}
			return new Object[][] {{
				newParameters
			}};
			
		}
		
		public String getProjectName() {
			return projectName;
		}
		
		//This method checks every time when we exeutes any component to check the current project name
		//if its not then it sets to the projectname to current project name
		
		public void setProjectName(String projectName) {
			this.projectName=projectName;
			if(!Configurables.projectName.equalsIgnoreCase(ProjectName.toString()) && Utils.checkExists(Config.getProp("ConfigSourceType"))
					&& Config.getProp("ConfigSourceType").equalsIgnoreCase("Excel")) {
				Map<String,String> updateMap=new HashMap<>();
				Map<String,Map<String,String>> projectInfo=new HashMap<>();
				updateMap=TestUtils.getProjectConfigMap("./Config.xlsx",projectName);
				Config.addProps(updatedMap);
				Configurables.updateConfigurablesValue();
				configDetailsProjectWise.put(projectName,updatedMap);
			}
		}
		
		//To get the project specific config details
		
		public  Map<String,String> getConfigDetailsProjectWise(String projectName){
			return TestUtils.getProjectConfigMap("./Config.xlsx",projectName);
		}
		
		@org.testng.annotations.BeforeMethod
		public void BeforeMethod(Method method, Object[] testData,ITestContext context) {
			if(testData.length >0) {
				testName.set(context.getName()+": "+method.getName());
				context.setAttribute("testName",testName.get());
				context.setCurrentXmlTest().setName(Config.getProp("Projectname"));
			}else
				context.setAttribute("testName",method.getName());
		}
		
		@Override
		public String getTestName() {
			return testName.get();
		}
	}
	
	

