package com.javaexcel.tests.base;

public class APITestBase extends TestBase {

}
