package com.javaexcel.testrunner;

import com.javaexce.automation.core.execution.Main;
public class TestRunner {
	public static void main(String[] arg) {
		Main.main(args);
	}

}
